#include "sort.h"
int main()
{
    employee *arr=(employee*)malloc(sizeof(employee)*100);
    FILE *fp=fopen("data.txt","r");
    int k=0;
    int def=100;
    while(fscanf(fp,"%s %lld",arr[k].name,&arr[k].empID)!=-1)
    {
        if(k==def-1)
        {
            def+=100;
            arr=(employee*)realloc(arr,sizeof(employee)*def);
        }
        k++;
    }
    qs(arr,0,k-1,10);
    int i=0;
    for(i=0;i<k;i++)
    printf("%s %lld\n",arr[i].name,arr[i].empID);
}
