#include "sort.h"
void qs(employee arr[],int lo,int hi,int S)
{
    stack s=push(newStack(),lo,hi);
    while(isEmpty(s)==0 && (hi-lo+1)>S)
    {
        node n=top(s);
        s=pop(s);
        while(n->lo<n->hi)
        {
            int p=partition(arr,n->lo,n->hi,lo);
            s=push(s,n->lo,p-1);
            n->lo=p+1;
        }
    }
    insertionSort(arr,lo,hi);
}
//int pivot(employee arr[],int lo,int hi,int p)
int partition(employee arr[],int lo,int hi,int p)
{
    int lt=lo-1;
    int rt=hi+1;
    int k=arr[p].empID;
    while(1)
    {
    do
    {
        ++lt;
    }while(arr[lt].empID<k);
    do
    {
        --rt;
    }while(arr[rt].empID>k);
    if(lt>=rt)
    return rt;
    swap(arr+lt,arr+rt);
    }
}
void swap(employee *a,employee *b)
{
    employee temp=*a;
    *a=*b;
    *b=temp;
}
void insertionSort(employee arr[],int lo,int hi)
{
    int i,j;
    for(i=lo;i<hi;i++)
    {
        employee a=arr[i+1];
        j=i;
        while(j>=lo && arr[j].empID>a.empID)
        {
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=a;
    }
}

